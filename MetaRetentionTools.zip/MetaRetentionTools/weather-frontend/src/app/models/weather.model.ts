export interface WeatherResponse {
  city: string;
  temperature: number;
  condition: string;
  sunrise?: number;
  sunset?: number;
  timestamp: string;
}
