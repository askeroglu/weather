import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { WeatherResponse } from '../models/weather.model';
 import { Observable, switchMap } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class WeatherService {
   private apiUrl = 'http://localhost:5295';

   constructor(private http: HttpClient) {}

   getWeather(unit: 'metric' | 'imperial'): Observable<WeatherResponse[]> {
     return this.setUnit(unit).pipe(
       switchMap(() => this.http.get<WeatherResponse[]>(`${this.apiUrl}/weather`))
     );
   }

   setUnit(unit: 'metric' | 'imperial'): Observable<string> {
     return this.http.post(`${this.apiUrl}/unit`, JSON.stringify(unit), {
       headers: { 'Content-Type': 'application/json' },
       responseType: 'text',
     });
   }

   getTrends(): Observable<Record<string, string>> {
     return this.http.get<Record<string, string>>(`${this.apiUrl}/weather/trend`);
  }
}

// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import {
//   BehaviorSubject,
//   Observable,
//   switchMap,
//   tap,
//   shareReplay,
//   catchError,
//   throwError,
// } from 'rxjs';
// import { WeatherResponse } from '../models/weather.model';

// @Injectable({ providedIn: 'root' })
// export class WeatherService {
//   private apiUrl = 'http://localhost:5295';

//   private unit$ = new BehaviorSubject<'metric' | 'imperial'>('metric');

//   // Weather data reacts to unit changes
//   public readonly weather$: Observable<WeatherResponse[]> = this.unit$.pipe(
//     switchMap((unit) =>
//       this.setUnit(unit).pipe(
//         switchMap(() =>
//           this.http.get<WeatherResponse[]>(`${this.apiUrl}/weather`)
//         )
//       )
//     ),
//     shareReplay(1), // cache latest value
//     catchError((err) => {
//       console.error('Error fetching weather:', err);
//       return throwError(() => err);
//     })
//   );

//   constructor(private http: HttpClient) {}

//   /** Exposed to components */
//   changeUnit(unit: 'metric' | 'imperial') {
//     this.unit$.next(unit);
//   }

//   /** Called internally before each weather fetch */
//   private setUnit(unit: 'metric' | 'imperial'): Observable<string> {
//     return this.http.post(`${this.apiUrl}/unit`, JSON.stringify(unit), {
//       headers: { 'Content-Type': 'application/json' },
//       responseType: 'text',
//     });
//   }

//   getTrends(): Observable<Record<string, string>> {
//     return this.http.get<Record<string, string>>(`${this.apiUrl}/weather/trend`);
//   }

//   getCurrentUnit(): 'metric' | 'imperial' {
//     return this.unit$.value;
//   }
// }

