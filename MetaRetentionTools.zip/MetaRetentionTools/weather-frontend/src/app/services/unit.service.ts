import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class UnitService {
  private key = 'unit';

  getUnit(): 'metric' | 'imperial' {
    return (sessionStorage.getItem(this.key) as 'metric' | 'imperial') || 'metric';
  }

  setUnit(unit: 'metric' | 'imperial') {
    sessionStorage.setItem(this.key, unit);
  }
}
