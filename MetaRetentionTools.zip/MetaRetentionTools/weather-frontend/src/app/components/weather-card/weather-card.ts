import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { WeatherService } from '../../services/weather.service';
import { WeatherResponse } from '../../models/weather.model';
import { Subscription } from 'rxjs';
import { CommonModule } from '@angular/common';
import { UnitService } from '../../services/unit.service';
import {
  trigger,
  transition,
  style,
  animate,
} from '@angular/animations';

import { timeout, catchError, throwError } from 'rxjs';

@Component({
  selector: 'app-weather-card',
  templateUrl: './weather-card.html',
  styleUrls: ['./weather-card.scss'],
  animations: [
    trigger('slideIn', [
      transition(':enter', [
        style({ transform: 'translateX(-20px)', opacity: 0 }),
        animate('400ms ease-out', style({ transform: 'translateX(0)', opacity: 1 })),
      ]),
    ]),
    trigger('fadeIn', [
      transition(':enter', [
        style({ opacity: 0, transform: 'translateY(10px)' }),
        animate('500ms ease-out', style({ opacity: 1, transform: 'none' })),
      ]),
    ]),
  ],
  imports: [CommonModule], 
})

export class WeatherCardComponent implements OnInit, OnDestroy {
  unit: 'metric' | 'imperial' = 'metric';  // default
  weatherData: WeatherResponse[] = [];
  trends: Record<string, string> = {};
  radioDisabled = false;

  private subscription?: Subscription;

  constructor(
    private weatherService: WeatherService,
    private unitService: UnitService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
     this.unit = this.unitService.getUnit();
     this.loadWeather();
     this.loadTrends();
  }

  loadWeather() {
     this.subscription = this.weatherService.getWeather(this.unit).subscribe({
       next: (data) => {
         console.log('Weather response:', data);
         this.weatherData = data;
         this.cdr.markForCheck();
       },
       error: (err) => {
         console.error('Failed to load weather data', err);
       },
     });
  }

  loadTrends() {
    this.weatherService.getTrends().subscribe({
      next: (data) => (this.trends = data),
      error: (err) => console.error('Failed to load trends', err)
    });
  }

  getTrendIcon(city: string): string {
    const trend = this.trends[city];
    if (trend === 'rising') return '⬆️';
    if (trend === 'falling') return '⬇️';
    if (trend === 'stable') return '➡️';
    return '';
  } 

  getTrendTooltip(city: string): string {
    const trend = this.trends[city];
    return trend ? `${trend} in the last 3 hours` : 'No trend data';
  }  

  onUnitChange(unit: 'metric' | 'imperial') {
     if (unit !== this.unit) {
       this.radioDisabled = true;

       this.unit = unit;
       this.unitService.setUnit(unit);

       setTimeout(() => {
         this.radioDisabled = false;
       }, 2500);

      this.weatherService.getWeather(unit).pipe(
         timeout(4000),
         catchError(err => {
          if (err.name === 'timeouterror') {
             console.error('request timed out');
             alert('request timed out. please try again.');
           } else {
             console.error('failed to load weather data', err);
           }
           return throwError(() => err);
        })
       ).subscribe({
         next: (data) => {
           this.weatherData = data;
           this.cdr.markForCheck();
         },
       });
     }
   }

  ngOnDestroy() {
    this.subscription?.unsubscribe();
  }

  getWeatherIcon(condition: string): string {
    const map: Record<string, string> = {
      clear: '01d',
      clouds: '03d',
      rain: '10d',
      snow: '13d',
      drizzle: '09d',
      thunderstorm: '11d',
      mist: '50d',
    };

    const key = condition.toLowerCase();
    const iconCode = map[key];

    if (!iconCode) {
      console.warn('Unknown weather condition:', condition);
    }

    return `http://openweathermap.org/img/wn/${iconCode || '01d'}@2x.png`;
  }

  formatUnixTime(timestamp?: number): string {
    return timestamp ? new Date(timestamp * 1000).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : 'N/A';
  }

}
