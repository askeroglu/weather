import { Routes } from '@angular/router';
import { WeatherCardComponent } from './components/weather-card/weather-card';

export const routes: Routes = [
  { path: 'weather', component: WeatherCardComponent },
  { path: '', redirectTo: 'weather', pathMatch: 'full' },  // redirect root to /weather
  { path: '**', redirectTo: 'weather' }  // fallback to /weather for unknown routes
];