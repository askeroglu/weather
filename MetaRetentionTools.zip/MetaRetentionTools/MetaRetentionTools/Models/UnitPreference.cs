﻿namespace MetaRetentionTools.Models;

public static class UnitPreference
{
    public static string Unit { get; set; } = "metric"; // Default to Celsius
}
