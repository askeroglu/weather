﻿namespace MetaRetentionTools.Models;

public class WeatherResponse
{
    public string City { get; set; } = "";
    public double Temperature { get; set; }
    public string Condition { get; set; } = "";
    public long Sunrise { get; set; }
    public long Sunset { get; set; }
    public DateTime Timestamp { get; set; }
}
