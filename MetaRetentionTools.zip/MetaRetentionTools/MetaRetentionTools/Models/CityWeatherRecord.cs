﻿namespace MetaRetentionTools.Models;

public class CityWeatherRecord
{
    public string City { get; set; } = "";
    public List<double> PastTemperatures { get; set; } = new();
}
