﻿using Microsoft.AspNetCore.Mvc;
using MetaRetentionTools.Interfaces;
using MetaRetentionTools.Models;

namespace MetaRetentionTools.Controllers;

[ApiController]
[Route("[controller]")]
public class WeatherController : ControllerBase
{
    private readonly IWeatherService _weatherService;
    private readonly ICacheService _cacheService;
    private readonly ITrendService _trendService;

    public WeatherController(
        IWeatherService weatherService,
        ICacheService cacheService,
        ITrendService trendService)
    {
        _weatherService = weatherService;
        _cacheService = cacheService;
        _trendService = trendService;
    }

    [HttpGet]
    public async Task<IActionResult> GetWeather()
    {
        var cities = Constants.Cities;
        var results = new List<WeatherResponse>();

        foreach (var city in cities)
        {
            if (_cacheService.TryGet(city, out var cached))
            {
                results.Add(cached!);
            }
            else
            {
                var weather = await _weatherService.GetWeatherAsync(city, UnitPreference.Unit);
                if (weather != null)
                {
                    _cacheService.Set(city, weather);
                    _trendService.Record(city, weather.Temperature);
                    results.Add(weather);
                }
            }
        }

        return Ok(results);
    }

    [HttpPost("/unit")]
    public IActionResult SetUnit([FromBody] string unit)
    {
        if (unit != "metric" && unit != "imperial")
            return BadRequest("Invalid unit. Use 'metric' or 'imperial'.");

        UnitPreference.Unit = unit;
        return Ok($"Unit set to {unit}");
    }

    [HttpGet("trend")]
    public IActionResult GetTrends()
    {
        var trends = Constants.Cities.ToDictionary(
            city => city,
            city => _trendService.GetTrend(city)
        );

        return Ok(trends);
    }
}
