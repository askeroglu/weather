﻿namespace MetaRetentionTools.Interfaces;

public interface ITrendService
{
    void Record(string city, double temperature);
    string GetTrend(string city);
}
