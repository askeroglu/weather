﻿namespace MetaRetentionTools.Interfaces;

using MetaRetentionTools.Models;

public interface IWeatherService
{
    Task<WeatherResponse?> GetWeatherAsync(string city, string units);
}
