﻿namespace MetaRetentionTools.Interfaces;

using MetaRetentionTools.Models;

public interface ICacheService
{
    bool TryGet(string city, out WeatherResponse? response);
    void Set(string city, WeatherResponse response);
}
