﻿using MetaRetentionTools.Interfaces;
using MetaRetentionTools.Models;

namespace MetaRetentionTools.Services;

public class CacheService : ICacheService
{
    private readonly Dictionary<string, (WeatherResponse, DateTime)> _cache = new();
    //private readonly TimeSpan _expiration = TimeSpan.FromMinutes(10);
    private readonly TimeSpan _expiration = TimeSpan.FromSeconds(3);

    public bool TryGet(string city, out WeatherResponse? response)
    {
        if (_cache.TryGetValue(city, out var entry) && DateTime.UtcNow - entry.Item2 < _expiration)
        {
            response = entry.Item1;
            return true;
        }
        response = null;
        return false;
    }

    public void Set(string city, WeatherResponse response)
    {
        _cache[city] = (response, DateTime.UtcNow);
    }
}
