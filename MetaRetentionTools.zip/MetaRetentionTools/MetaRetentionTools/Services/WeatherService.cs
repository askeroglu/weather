﻿using System.Text.Json;
using MetaRetentionTools.Interfaces;
using MetaRetentionTools.Models;

namespace MetaRetentionTools.Services;

public class WeatherService : IWeatherService
{
    private readonly HttpClient _httpClient;
    private readonly IConfiguration _configuration;
    private readonly ITrendService _trendService;

    public WeatherService(HttpClient httpClient, IConfiguration configuration, ITrendService trendService)
    {
        _httpClient = httpClient;
        _configuration = configuration;
        _trendService = trendService;
    }

    public async Task<WeatherResponse?> GetWeatherAsync(string city, string units)
    {
        var apiKey = _configuration["OpenWeather:ApiKey"];
        var baseUrl = _configuration["OpenWeather:BaseUrl"];
        var url = $"{baseUrl}?q={city}&appid={apiKey}&units={units}";

        try
        {
            var response = await _httpClient.GetFromJsonAsync<JsonElement>(url);

            var temp = response.GetProperty("main").GetProperty("temp").GetDouble();
            // Record temperature to trend service
            _trendService.Record(city, temp);

            return new WeatherResponse
            {
                City = city,
                Temperature = response.GetProperty("main").GetProperty("temp").GetDouble(),
                Condition = response.GetProperty("weather")[0].GetProperty("main").GetString() ?? "Unknown",
                Sunrise = response.GetProperty("sys").GetProperty("sunrise").GetInt64(),
                Sunset = response.GetProperty("sys").GetProperty("sunset").GetInt64(),
                Timestamp = DateTime.UtcNow
            };
        }
        catch
        {
            return null;
        }
    }
}
