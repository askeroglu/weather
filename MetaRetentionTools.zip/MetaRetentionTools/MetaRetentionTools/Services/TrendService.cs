﻿using MetaRetentionTools.Interfaces;
using MetaRetentionTools.Models;

namespace MetaRetentionTools.Services;

public class TrendService : ITrendService
{
    private readonly Dictionary<string, CityWeatherRecord> _history = new();

    public void Record(string city, double temperature)
    {
        if (!_history.ContainsKey(city))
            _history[city] = new CityWeatherRecord { City = city };

        _history[city].PastTemperatures.Add(temperature);

        if (_history[city].PastTemperatures.Count > 20)
            _history[city].PastTemperatures.RemoveAt(0);
    }

    public string GetTrend(string city)
    {
        if (!_history.ContainsKey(city) || _history[city].PastTemperatures.Count < 2)
            return "No Data";

        var temps = _history[city].PastTemperatures;
        var trend = temps[^1] - temps[^2];

        if (trend > 0.3) return "rising";
        if (trend < -0.3) return "falling";
        return "stable";
    }
}
