﻿namespace MetaRetentionTools;

public static class Constants
{
    public static readonly List<string> Cities = new()
    {
        "London", "Vienna", "Ljubljana", "Belgrade", "Valletta"
    };
}
